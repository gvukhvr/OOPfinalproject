package Course;

public enum Format {
	ONLINE, OFFLINE
}
