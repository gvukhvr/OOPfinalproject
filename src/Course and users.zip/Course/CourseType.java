package Course;

public enum CourseType {
	Major, Minor, FreeChoice;
}
