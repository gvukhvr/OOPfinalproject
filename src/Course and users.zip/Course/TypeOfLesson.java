package Course;

public enum TypeOfLesson {
	LECTURE, LAB, PRACTICE;
}
