package Users;

public enum ManagerType {
	OR,
	Faculty,
	Department
}
