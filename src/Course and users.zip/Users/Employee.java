package Users;

import java.io.IOException;
import java.util.Date;
import java.util.Objects;

import staff.Employee;
import utilities.DataSingleton;
import utilities.Message;
import utilities.Request;

public class Employee extends User {
    protected double salary;
    protected Date hireDate;

    // Default constructor
    public Employee(String firstName, String lastName) {
        super(firstName, lastName);
        
    }
    public Employee() {}

    public Employee(String firstName, String lastName, double salary) {
        super(firstName, lastName); 
        this.salary = salary;
        this.hireDate = new Date();
    }

    // Constructor with full details including email and password (inherits from User)
    public Employee(Integer id, String firstName, String lastName, String email, String password, double salary) {
        super(id, firstName, lastName, email, password); // Assumes User class has this constructor
        this.salary = salary;
        this.hireDate = new Date(); // Current date as hire date
    }

    // Getters and Setters
    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public Date getHireDate() {
        return hireDate;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }
    
    public void sendMessage(String text, Employee e) throws Exception {
		Message m = new Message(e, text);
		m.setSender(this);
		SavedData.INSTANCE.addMessages(m);
		
	}

	
	public Message getMessage() {
		for(Message m: DataSingleton.INSTANCE.getMessages()) {
			if(m.getReceiver().equals(this)) {
				return m;
			} 
		}
		return null;
	}
	/**
     * Sends a request on behalf of the employee
     * @param r The request to be sent
     * @throws IOException If an error occurs during request sending
     */
	public void sendRequest(Request r) throws IOException {
		r.setSender(this);
		SavedData.INSTANCE.addRequests(r);
	}

    // ToString method - Returns Employee details along with inherited User details
    @Override
    public String toString() {
        return super.toString() + " Employee{" +
               "salary=" + salary +
               ", hireDate=" + hireDate +
               '}';
    }

    // Overriding hashCode - Ensures consistent hashCode with equals
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + Objects.hash(salary);
        return result;
    }

    // Overriding equals - Checks if Employee objects are equal based on salary and inherited fields
    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj)) return false;
        Employee other = (Employee) obj;
        return Double.doubleToLongBits(salary) == Double.doubleToLongBits(other.salary);
    }
}
