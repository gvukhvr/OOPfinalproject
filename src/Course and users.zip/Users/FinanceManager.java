package Users;

import java.io.IOException;


public class FinanceManager extends Employee {
	protected String dataSalary;
	
	public FinanceManager(String firstName, String lastName) {
		super(firstName, lastName);
		
	}

    public FinanceManager(Integer id, String firstName, String lastName, String email, String password, double salary) {
        super(id, firstName, lastName, email, password, salary); 
       
    }
    
    public void sendSalary(Employee e) throws Exception {
		Message m = new Message(e, "your salary: ", salary);
		m.setSender(this);
		SavedData.INSTANCE.addMessages(m);
		
	}
    
    public void getSalaryInfo() {
		Utils.printList(SavedData.INSTANCE.getSalaryInfo());
    }

	
	
}
