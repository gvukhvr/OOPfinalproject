package Users;

import java.util.Date;
import java.util.Objects;


public class Manager extends Employee {
    protected ManagerType type;

    public Manager() {}
    
    public Manager(String firstName, String lastName, double salary, ManagerType type ) {
        super(firstName, lastName, salary);
        this.type = type;
    }

    public Manager(Integer id, String firstName, String lastName, String email, String password, double salary,  ManagerType type) {
        super(id, firstName, lastName, email, password, salary);
        this.type = type;
    }
    
    @Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(type);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (!super.equals(obj)) return false;
		Manager other = (Manager) obj;
		return type == other.type;
	}

	@Override
	public String toString() {
		return super.toString() + "Manager " + type;
	}

    public ManagerType getType() {
		return type;
	}

	public void setType(ManagerType type) {
		this.type = type;
	}

	public void addCoursesForReg(Course course) {
        // Заглушка
    }

    public void deleteCoursesFromReg(Course course) {
        // Заглушка
    }

    public void approveRegistration(Student student) {
        // Заглушка
    }

    public void addNews(String news) {
        // Заглушка
    }

    public void viewInfoStudents() {
        // Заглушка
    }

    public void viewInfoTeachers() {
        // Заглушка
    }

    public Vector<Student> viewStudentsSortedByGpa() {
        // Возвращаем пустой вектор для примера
        return new Vector<>();
    }

    public Vector<Student> viewStudentsSortedByName() {
        return new Vector<>();
    }

    public void addLessonToSystem(Lesson lesson) {
        // Заглушка
    }

    public void removeLessonFromSystem(Lesson lesson) {
        // Заглушка
    }

    public void addLessonToTeacher(Teacher teacher, Lesson lesson) {
        // Заглушка
    }

    public void removeLessonFromTeacher(Teacher teacher, Lesson lesson) {
        // Заглушка
    }

    public void addLessonToStudent(Student student, Lesson lesson) {
        // Заглушка
    }

    public void removeLessonFromStudent(Student student, Lesson lesson) {
        // Заглушка
    }
}