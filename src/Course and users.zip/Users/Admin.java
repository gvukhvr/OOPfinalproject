package Users;

import java.util.Date;

public class Admin extends Employee
{


	public Admin() {
		
	}
	
	
	public Admin(String firstName, String lastName) {
		super(firstName, lastName);
		
	}

    public Admin(Integer id, String firstName, String lastName, String email, String password, double salary) {
        super(id, firstName, lastName, email, password, salary); 
       
    }
    public void addUser(User user) {
        // Заглушка
    }

    public void changeUser(User user) {
        // Заглушка
    }

    public void removeUser(User user) {
        // Заглушка
    }

    public String viewAllUser(User user) {
        // Заглушка: возвращаем строковое представление
        return user.toString();
    }
}
