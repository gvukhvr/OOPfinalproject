package Users;

public interface Serializable {

}
